<footer class="footer">
    <div class="footer-text">
        <p>Copyright &copy; <?php echo date("Y"); ?> by Syifa Nur Nabila | All Rights Reserved</p>
    </div>
</footer>
